package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        System.out.println("Starting");
        while (true){
            try {
                String senddata = senddata();
                if (senddata.equals("true")){
                    break;
                }
                Thread.sleep(1000 * 60 * 2);
            } catch (Exception exception){
                logWarning(exception.getMessage());
                try {
                    Thread.sleep(1000 * 60 * 2);
                } catch (InterruptedException e) {
                    continue;
                }
            }
        }
    }

    public static String senddata() {
        String DB_URL = "jdbc:postgresql://ep-snowy-cherry-a5cbwpfu.us-east-2.aws.neon.tech/naqd";
        String DB_USER = "naqd_owner";
        String DB_PASSWORD = "sFet4nhVP5cp";
        String database = LocalDateTime.now().toLocalDate().toString();
        String csvFile = "/home/uchkoprik/Documents/ai/" + database + ".txt";
        System.out.println(csvFile);

        String line;
        String csvSplitBy = ",";

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile));
             Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {

            String insertSQL = "INSERT INTO car_data (car_id, duration, end_date, start_date, ad_id, frame_id, person_id,created_at) " +
                    "VALUES (?, ?, ?, ?, 7, 2, ?,?)";
            Long l = 0L;
            while ((line = br.readLine()) != null) {
                try {
                    String[] data = line.split(csvSplitBy);

                    int classId = Integer.parseInt(data[0]);
                    long value = Long.parseLong(data[1]);
                    double duration = Double.parseDouble(data[2]);
                    Timestamp timestamp = Timestamp.valueOf(data[3]);

                    try (PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
                        if (classId == 0) {
                            pstmt.setNull(1, java.sql.Types.BIGINT);
                            pstmt.setNull(5, java.sql.Types.BIGINT);
                            pstmt.setLong(5, value); // person_id
                        } else if (classId == 2) {
                            pstmt.setLong(1, value); // car_id
                            pstmt.setNull(5, java.sql.Types.BIGINT);
                        }

                        pstmt.setDouble(2, duration);
                        pstmt.setTimestamp(3, timestamp);
                        pstmt.setTimestamp(4, timestamp);
                        pstmt.setTimestamp(6, timestamp);

                        pstmt.executeUpdate();
                    }
                    Thread.sleep(300);
                    System.out.println("inserted "+l);
                    l++;
                } catch (Exception e) {
                    logWarning(e.getMessage());
                    e.printStackTrace();
                    l++;
                }
            }
            System.out.println("Data has been inserted successfully.");
            return "true";
        } catch (IOException | SQLException e) {
            logWarning(e.getMessage());
            e.printStackTrace();
        }

        return "false";
    }


    static {
        try {
            FileHandler fileHandler = new FileHandler("/home/uchkoprik/Documents/logs/java.log", true); // true - faylni davomiy rejimda ochish
            fileHandler.setFormatter(new SimpleFormatter()); // Log formatini sozlaymiz
            logger.addHandler(fileHandler); // Loggerga handler qo'shamiz
            logger.setLevel(java.util.logging.Level.ALL); // Hamma darajadagi loglarni yozish
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void logInfo(String message) {
        logger.info(message); // Info darajasidagi log yozamiz
    }

    public static void logWarning(String message) {
        logger.warning(message); // Warning darajasidagi log yozamiz
    }

    public static void logSevere(String message) {
        logger.severe(message); // Severe darajasidagi log yozamiz
    }
}
